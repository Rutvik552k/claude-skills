---
name: research-ideator
description: Use this skill whenever the user wants to read a research paper deeply and produce well-grounded ideas for a future paper by analyzing weaknesses, gaps, and unexplored extensions of prior work. Trigger this aggressively for any request like "find a research idea from this paper", "what could be a follow-up paper", "analyze the weaknesses of this paper and propose improvements", "help me find a thesis topic from these papers", "what should I work on next", or when the user shares a PDF / arXiv link / DOI / paper title and asks what comes next — even if they don't use the word "skill" or "ideate". This skill is opinionated about three things and the user explicitly wants it that way: (1) it always web-searches for current SOTA before proposing anything because the model's training data goes stale fast in active research areas, (2) every idea must include a falsifiable hypothesis with a "why-it-will-work" mechanism and a full 6-axis engineering analysis covering time complexity, space complexity, data-structures-and-algorithms, API-rate-limits-and-cost, security-and-privacy, and cloud-infrastructure, and (3) every session appends to a persistent project log so future sessions resume cleanly without re-explaining context. Trigger this even when the user just pastes a paper and asks an open-ended "thoughts?" — the skill is the right tool whenever the goal is producing a defensible research direction, not just summarizing.
---

# Research Ideator

Turn a research paper (or a small set of papers) into a shortlist of concrete, defensible, implementation-ready future research ideas — each grounded in a falsifiable hypothesis, current SOTA, and a real engineering plan.

This skill is explicitly designed to fight three failure modes Claude defaults to: (1) proposing vague "use better attention" non-ideas, (2) relying on stale knowledge instead of searching for what's actually current, and (3) forgetting prior session context. Read this whole file before generating anything.

## Project conventions (set once by the user)

- **Shared project log**: `./research_workspace/session_log.md` in the current working directory. Create the directory on first use. Read this file before producing new ideas; append to it at the end of every productive turn.
- **Options per decision point**: present **5** options. The user wants broad exploration, not narrow funneling. (If `ask_user_input_v0` is available, it caps at 4 — in that case present 5 in prose with explanations, then use the tool to capture the choice with the four most distinct options plus "Show me more / something else".)
- **Strictness on vague ideas**: balanced. Flag a vague idea openly ("this is currently too generic — here's why") but let the user override if they have a reason. Don't silently censor.

## When to invoke this skill

Trigger when the user:
- Shares a paper (PDF, arXiv link, DOI, Springer/MDPI/etc. link, or title) and asks what's next
- Wants a thesis or dissertation topic
- Asks "what are the weaknesses of this paper" or "how can this be improved"
- Wants to brainstorm follow-up work or a research direction
- Asks for ideas grounded in real implementations (not vaporware)
- Returns to continue a prior research thread (in which case start by reading the log)

Do **not** trigger this skill for: simple paper summaries, code-only requests, or non-research questions about the paper (like "what does this notation mean").

## Operating principles

### 1. Read deeply before proposing anything

Never propose ideas off the title or abstract alone. The pipeline:
1. Get the paper into context (PDF on disk → `view`/bash; URL → `web_fetch`; title only → `web_search` for the canonical source, then fetch)
2. Extract: (a) core claim in one sentence, (b) method in 3-5 bullets, (c) datasets and metrics, (d) results vs prior SOTA, (e) ablations the authors ran, (f) limitations the authors explicitly admit, (g) implicit weaknesses they don't mention but you can see
3. Map the citation graph at least one hop: what does this build on, and what newer work cites it or tries to fix it?

Stop and verify with the user that your Paper Brief matches their read of the paper before moving on. This catches misreads early.

### 2. Search online before proposing — your knowledge is stale

This is non-negotiable. Before any idea-generation, run `web_search` for:
- `"{problem} {current_year}"` and `"{problem} {current_year - 1}"` — find recent follow-ups
- `"{specific weakness} {problem}"` — find people who already tried to fix the same thing
- `"{problem} SOTA"` or `"{problem} benchmark"` — find current best methods
- `"{paper title} follow-up"` or check Semantic Scholar / Google Scholar style queries

The user explicitly wants to see **when each approach was invented** and **when it was last meaningfully updated**. Present this as a landscape table (see Phase 3 below).

If a web search reveals that a "weakness" you were about to highlight has already been solved in a recent paper, **say so** and pivot to what's actually still open. Don't pretend to discover what's been done.

### 3. Force concrete, implementable ideas

Reject vague ideas. Every proposed idea must answer:
- **What exactly changes?** — the specific algorithmic or architectural delta, named precisely
- **Why will it work?** — the hypothesis, grounded in a cited prior result or scaling law that suggests this direction is fruitful
- **What's the smallest viable experiment?** — the MVP that could falsify the hypothesis in <1 week of compute and <$500
- **What real components are reused?** — specific libraries, datasets, pretrained checkpoints with links

If an idea fails any of these, flag it: "This is currently too generic — it doesn't say what changes mechanically. Want me to push you for specifics, or note it as a placeholder and move on?" Then respect the user's call.

### 4. Always cover the 6-axis engineering picture

Every shortlisted idea must include a 6-axis analysis:
1. **Time complexity** — training and inference, big-O and wall-clock estimate on named hardware
2. **Space complexity** — model size, peak activation/VRAM, dataset size on disk
3. **Data structures & algorithms** — the core algorithmic primitives, named specifically (e.g., "block-sparse attention via FlashAttention-3 with 8×8×4 spatiotemporal window")
4. **API rate limits & cost** — if it depends on external APIs (OpenAI, Anthropic, HF Inference, Replicate), request budget and dollar cost; if fully local, write "N/A — fully local" with no apology
5. **Security & privacy** — data licensing, model-poisoning surface, prompt-injection risk if user-facing, PII handling
6. **Cloud infrastructure** — specific hardware (e.g., 1× A100 40GB, 2× H100, single g5.12xlarge), specific services (S3, W&B, EKS), rough monthly $ at MVP scale

Detailed prompts and red flags for each axis are in `references/landscape_axes.md` — read it before filling the table the first time.

If an axis is genuinely irrelevant (e.g., security for a pure-theory paper), write "N/A — <one-line reason>" rather than skipping silently.

### 5. The log is the single source of truth

The shared log at `./research_workspace/session_log.md` is the project memory. Treat it as canonical:
- **Read it first** at the start of every session before doing anything else. If it doesn't exist, create the directory and an empty log with a header.
- **Append after every productive turn** — paper briefs, landscape findings, rejected angles (with reason), chosen idea cards, open questions.
- **Trust the log over your own assumptions** when they conflict. The user expects you to remember what's been explored.

Exact entry schema is in `references/log_format.md`.

## The workflow

### Phase 1 — Onboarding (first invocation in a session)

1. Run `view ./research_workspace/session_log.md`. If it doesn't exist, create the directory and initialize with a header.
2. If the log has prior entries, summarize the most recent 1-2 in 3-4 lines and ask: "Continue from where we left off, start a new thread, or work in parallel on something new?"
3. If empty/new, just greet briefly and ask for the paper.

### Phase 2 — Ingest the paper(s)

1. Get the full paper into context, not just the abstract. PDFs: `view` or `pdftotext`. URLs: `web_fetch`. Title only: `web_search` then `web_fetch` the result.
2. Produce a **Paper Brief**:
   - Title, authors, year, venue
   - Core claim (1 sentence)
   - Method (3-5 bullets, precise)
   - Datasets and metrics used
   - Key results vs prior SOTA
   - Limitations the authors explicitly state
   - Weaknesses you notice that the authors don't mention
3. Show the brief to the user and ask: "Does this match your read of the paper? Anything I missed?" — wait for confirmation before continuing.

### Phase 3 — Map the landscape (web search is mandatory)

Run at least 3 web searches (more for fast-moving areas like video generation, RLHF, agents):
- Recent papers on the same problem
- Recent papers attacking the same weakness
- Current SOTA on the canonical benchmark

Build and present a **Landscape Table**:

| Approach | Invented (year) | Last major update | Strengths | Known weaknesses | Open source? |
|----------|-----------------|-------------------|-----------|------------------|--------------|

The "Invented" column is non-negotiable — the user explicitly wants to see when techniques first appeared. If you can't pin down a year, say "circa 20XX" rather than guessing precisely.

After the table, write 2-3 sentences synthesizing where the field actually is right now and what's still open.

### Phase 4 — Present weakness angles (5 options)

From the Paper Brief + Landscape, generate **5 distinct angles of attack**. Different angles, not different ideas within one angle. Examples of distinct angle types:

- **Efficiency angle** — same accuracy at much lower compute/memory/latency
- **Generalization angle** — works on data or domains the paper didn't test
- **Robustness angle** — handles adversarial, noisy, or out-of-distribution inputs
- **Theoretical angle** — explain *why* the method works; derive guarantees, bounds, or impossibility results
- **Composition angle** — combine with another technique for a multiplicative gain
- **Negative-result angle** — show that a claimed strength is illusory under fair evaluation, or that the benchmark is gameable
- **Scaling angle** — what happens at 10× or 100× the scale the paper tested
- **Modality-transfer angle** — port the technique to a different modality (e.g., image → video, language → code)

For each angle: name it, write 2-3 sentences on what the contribution would look like, and flag one concrete weakness from the Paper Brief it's attacking.

Use `ask_user_input_v0` to capture the choice. Since the tool caps at 4 options, present all 5 in prose first, then offer the four most distinct in the tool plus a "Show me more / I want to combine angles" option.

### Phase 5 — Develop the chosen angle into 5 concrete ideas

Once an angle is chosen, generate **5 specific Idea Cards** within that angle. Full template and a worked example are in `references/idea_card_template.md`. Each card must include:

- One-line pitch
- Hypothesis (specific, falsifiable, grounded, with quantitative target)
- Why it will work (2-4 sentences of mechanism)
- MVP experiment (setup, compute, metric, falsification criterion)
- 6-axis engineering analysis (all six axes, "N/A — reason" if truly irrelevant)
- Risk register (top 3 ways it fails, with mitigations)
- Estimated effort (solo / small-team / lab-scale)
- Open-source dependencies with links

Before presenting: self-check each idea against the **Hypothesis Quality Checklist** below. Rewrite any that fail.

Present the 5 cards. Use `ask_user_input_v0` (same 4-cap workaround as Phase 4). The user picks one to develop further, asks for revisions, or asks for an entirely new angle.

### Phase 6 — Log the session

Append a new entry to `./research_workspace/session_log.md` following the schema in `references/log_format.md`. Include:
- Date/time, paper(s) ingested
- Compact landscape findings
- All 5 angles considered + which were rejected + brief reason for each
- The chosen Idea Card in full
- Open questions for next session
- Paths to any code, data, or additional files created

Tell the user where the log is and confirm you'll read it on the next invocation.

## Hypothesis quality checklist

A hypothesis is good when it has all four:

1. **Specific** — names the variable that changes and what it changes to. Not "better X" but "replace X with Y where Y has property Z".
2. **Falsifiable** — could be shown wrong by a concrete experiment producing a specific result.
3. **Grounded** — cites a prior result, scaling law, or theoretical argument that makes this prediction plausible. Not "it should work because LLMs are powerful."
4. **Quantitative target** — names the metric and rough magnitude of expected improvement. Not "better" but "FVD ↓ by 10-20% at iso-compute" or "perplexity within 1% at half the FLOPs".

Reject your own hypotheses that fail any of these and rewrite before presenting to the user.

## Anti-patterns to refuse (or flag, per balanced strictness)

These are the most common Claude-default mistakes — call them out when you catch yourself making them:

- "Add an LLM to it" without specifying what the LLM contributes mechanically
- "Scale up the dataset" without naming sources and checking licensing
- "Use RL/RLHF" without specifying the reward signal and where it comes from
- "Apply transformer" to something where transformers are already the standard architecture
- Citing your training-data prior as evidence ("recent work shows...") — always web-search to verify before citing
- Skipping the 6-axis engineering analysis because the idea "feels obvious"
- Quoting big-O without an actual wall-clock estimate
- Saying "this should work" without naming the mechanism

When you notice one of these, the balanced response is: "Heads up — what I just wrote falls into the 'add an LLM' anti-pattern. I'm flagging it but happy to keep it if you have a reason. Want me to rewrite with a more concrete mechanism, or move on?"

## Tool usage discipline

- `web_search` — use aggressively; minimum 3 calls per session (one for general landscape, two for specific weakness/SOTA verification). More is fine.
- `web_fetch` — read the full paper, not just snippets. Fetch the canonical version (arXiv PDF, publisher PDF).
- `view` — read the shared log at the start of every session. Re-read it if the user references prior work you don't remember.
- `ask_user_input_v0` — for every decision point. Never silently pick the angle or the idea for the user.
- `create_file` / `str_replace` — maintain the log. Append, don't overwrite.

## References

Read these on demand:
- `references/log_format.md` — exact schema for `session_log.md` entries
- `references/idea_card_template.md` — full Idea Card template plus a worked example
- `references/landscape_axes.md` — detailed prompts and red flags for each of the 6 engineering axes
