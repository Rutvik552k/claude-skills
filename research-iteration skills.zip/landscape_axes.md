# 6-axis engineering analysis — prompts and red flags

When filling the engineering table for an Idea Card, use these prompts. If you can't answer the prompts with specifics, the idea isn't concrete enough yet — push back and refine before presenting it.

## 1. Time complexity

**Prompts to answer:**
- What's the big-O of training one step? Of one inference call?
- What dominates wall-clock? Compute, memory bandwidth, communication, or I/O?
- What's the actual estimated time for the MVP, in hours, on the specific hardware?
- For inference: what's the latency target and the latency at MVP scale?

**Red flags — refuse and rewrite if you catch yourself doing these:**
- "It's fast" without a wall-clock number
- Ignoring data loading / I/O for data-heavy ideas (often dominates GPU compute)
- Quoting peak FLOPs without accounting for memory bandwidth bottlenecks (modern GPUs are usually memory-bound for transformers)
- Forgetting that big-O hides constants that matter at real scale

**Good example:**
"Training: O(n·d²) per step where n = sequence length and d = hidden dim. Wall-clock ~14h on 8× H100 for 100K steps at batch 32, sequence 4096. Memory bandwidth bound, ~70% MFU."

## 2. Space complexity

**Prompts to answer:**
- Model parameters in GB (in inference precision)?
- Peak activation memory during forward+backward?
- Optimizer state size (Adam adds ~2× model size for fp32 states)?
- Dataset size on disk, raw and after preprocessing?
- KV cache size if inference-time relevant?

**Red flags:**
- Forgetting optimizer states (a 7B model needs ~84 GB in Adam fp32, not 14)
- Forgetting gradient accumulation memory
- Not accounting for activation checkpointing tradeoffs (saves memory at the cost of recompute time)
- Ignoring dataset preprocessing footprint (a 100GB raw dataset can easily 5× after tokenization + caching)

**Good example:**
"Model: 14 GB (7B in fp16). Optimizer states: 56 GB (Adam fp32 = 8 bytes/param). Activations with checkpointing: ~30 GB at batch 8. Total: ~100 GB — fits on 2× H100 80GB with room to spare. Dataset: 300 GB tokenized + cached on disk."

## 3. Data structures and algorithms

**Prompts to answer:**
- What's the *core* algorithmic primitive that makes this work? Name it specifically.
- Are there standard library implementations (PyTorch, JAX, NumPy, Faiss, scikit-learn, HuggingFace)?
- Are there known faster variants (approximate kNN vs exact, FlashAttention vs vanilla, fused kernels)?
- What's the index/data structure for any retrieval or lookup step?

**Red flags:**
- Hand-rolling something that already has a battle-tested implementation
- Using O(n²) where O(n log n) is the standard (e.g., naive attention when FlashAttention exists, full softmax over millions of classes when sampled softmax suffices)
- Ignoring sparse / approximate / streaming alternatives for large-scale primitives
- Vague phrases like "use attention" or "use a transformer" — name the specific variant and why

**Good example:**
"FAISS HNSW index over 10M document embeddings for retrieval (M=32, efConstruction=400), with PCA pre-projection from 1024 to 256 dims. FlashAttention-3 for the cross-attention layer. Reservoir sampling for streaming dataset construction. Trie for prefix-matching the candidate set."

## 4. API rate limits and cost

**Prompts to answer:**
- Does this depend on any external paid API (OpenAI, Anthropic, Cohere, HF Inference, Replicate, AWS Bedrock)?
- What's the per-request cost? How many requests does the MVP need? Total $?
- What's the rate limit (RPM, TPM, RPD)? Is the experiment serial or parallel within that limit?
- What's the retry strategy on rate-limit errors? Exponential backoff parameters?

**Red flags:**
- "We'll call GPT-4 for every sample" on a 1M-sample dataset (probably $50K+)
- Assuming free tiers will scale through to publishable scale
- Ignoring batching opportunities (most APIs are cheaper per-token in batch mode)
- No retry/backoff strategy for rate-limit errors

**Good example:**
"Calls Claude Sonnet 4 for ~5K judging queries during eval (1K input + 500 output tokens each). Cost: ~$50 per full eval run, plan for 5 runs across ablations = $250 budget. Rate limit (Tier 2): 80 RPM, 100K TPM — eval runs in ~10 min serially or 2 min with 5-way parallel. Retry with exponential backoff (1s, 2s, 4s, 8s) on 429."

If fully local, write: **"N/A — fully local execution"** and move on.

## 5. Security and privacy

**Prompts to answer:**
- Where does training data come from? Is the license compatible with intended use (research vs commercial)?
- Is the model exposed to untrusted user input (prompt injection risk)?
- If outputs affect real systems (code execution, financial decisions, content moderation), what's the failure mode and rollback story?
- Are there PII concerns in the data? GDPR/CCPA implications?
- Could the trained model be a vector for data extraction attacks (memorization of training data)?
- For agent / tool-use systems: what's the blast radius if the model is jailbroken?

**Red flags:**
- Training on scraped web data without checking robots.txt or ToS
- Deploying an LLM agent with tool use (file system, web, code execution) on a public surface without input validation and capability limits
- Storing user data in plaintext during training pipelines
- Releasing model weights trained on user data without deduplication / membership inference checks

**Good example:**
"Training on The Pile (research license, no PII filtering required for our use case — academic only). No user-facing deployment in MVP, so no prompt-injection surface. Will run membership inference test (Carlini et al. 2022 protocol) before any model release to flag memorization. Outputs are research artifacts only — no automated action downstream."

If genuinely irrelevant (e.g., pure-theory paper with no implementation, or fully synthetic data with no deployment), write: **"N/A — <one-line reason>"**.

## 6. Cloud infrastructure

**Prompts to answer:**
- What hardware does the MVP need? Be specific: model, count, memory tier. (1× A100 40GB, 2× H100 80GB, single g5.12xlarge, TPU v5e-8, etc.)
- Which provider is the right tradeoff for that hardware at the lowest cost? (Lambda Labs / RunPod / Vast.ai for cheap GPU rentals; AWS/GCP for production stability; Colab Pro for very small jobs)
- What supporting services? (S3/GCS/Azure Blob for checkpoints; W&B / Neptune / MLflow for tracking; Docker registry; CI/CD if applicable)
- Roughly $/month at MVP scale, and at "publishable scale" (including ablations)?
- What's the data egress story if datasets need to move between providers?

**Red flags:**
- "We'll use AWS" without specifying instance type or region
- Assuming SageMaker / Vertex AI is the cheapest option (usually 3-5× more than raw GPU rentals)
- Forgetting egress costs for moving large datasets between clouds (can be $0.05-0.09 per GB out of AWS)
- Reserved/committed-use discounts assumed for a research MVP that won't run long enough to amortize them

**Good example:**
"MVP: 1× A100 40GB on Lambda Labs (~$1.10/h, ~$30 for the MVP run). Checkpoints to Lambda's bundled storage, mirrored nightly to a personal S3 bucket ($2/month). Weights & Biases free tier for tracking. Publishable-scale ablations: 5 runs × $50 ≈ $250, plus ~$100 for human eval credits. Total project budget: ~$400."
