# Session log entry schema

The session log at `./research_workspace/session_log.md` is the canonical project memory. Every productive turn appends one entry. This file is read by future sessions of the skill to recover context — keep it structured and complete.

## Header (first-time setup only)

When creating the file for the first time, start with this header:

```markdown
# Research Ideator — Project Log

This file is the persistent memory of the research-ideator skill. Each session
appends one entry below following the schema in references/log_format.md of the
skill. Most recent entries are at the bottom.
```

## Entry template

Append each entry as a new section at the bottom of the file. Use this exact structure:

```markdown
---
## Session [YYYY-MM-DD HH:MM] — [Short title describing the focus]

### Paper(s) ingested
- **[Title]** — [Authors et al.], [Year], [Venue]. [DOI or arXiv ID].
- (one bullet per paper if multiple)

### Paper brief
- **Core claim:** [one sentence]
- **Method:** [3-5 bullets]
- **Datasets & metrics:** [list]
- **Key results:** [list with numbers]
- **Stated limitations:** [from the paper]
- **Unstated weaknesses noticed:** [your additions]

### Landscape findings

| Approach | Invented | Last update | Strengths | Weaknesses | Open source |
|----------|----------|-------------|-----------|------------|-------------|
| ...      | ...      | ...         | ...       | ...        | ...         |

Synthesis (2-3 sentences on where the field actually is right now): ...

### Angles considered

1. **[Angle name]** — status: *accepted* / *rejected* / *deferred*. Reason: [one or two sentences]
2. **[Angle name]** — status: ...
3. **[Angle name]** — status: ...
4. **[Angle name]** — status: ...
5. **[Angle name]** — status: ...

### Chosen idea

**Title:** ...

**One-line pitch:** ...

**Hypothesis:**
We hypothesize that [intervention] applied to [setting] will produce [outcome with quantitative target], because [mechanism], supported by [grounding citation/result].

**Why it will work:** [2-4 sentences]

**MVP experiment:**
- Setup: ...
- Compute: ...
- Metric: ...
- Falsification criterion: ...

**6-axis engineering analysis:**
| Axis | Analysis |
|------|----------|
| Time | ... |
| Space | ... |
| DSA | ... |
| API/cost | ... |
| Security | ... |
| Cloud infra | ... |

**Risks:**
1. [Risk] — likelihood [low/med/high]. Mitigation: ...
2. ...
3. ...

**Effort estimate:** [solo / small-team / lab-scale] — [rough month-equivalent]

**Open-source dependencies:**
- [name] — [URL] — [license note]
- ...

### Open questions for next session
- ...
- ...
- ...

### Files referenced or created
- [path] — [what it is]
- ...

---
```

## Reading the log at session start

Always run `view` on the log before doing anything else. If the log exceeds ~1000 lines, view only the last ~300 lines plus search for headers (`grep "^## Session" session_log.md`) to get an index.

The most recent "Open questions for next session" block is usually the right starting point when the user says "continue".

## What to NOT put in the log

- Full paper PDFs or large code dumps — store those as separate files in `./research_workspace/` and link to them from the log entry
- Casual chat or off-topic discussion — only research-substantive content goes here
- Speculation presented as fact — clearly mark hypotheses as hypotheses

## What to ALWAYS put in the log

- Every rejected angle and why it was rejected. This is the most valuable part of the log later — it prevents the user from re-litigating the same dead ends.
- The exact hypothesis as it stood when chosen, even if it gets revised later. Revisions get appended as new entries with a back-reference, not by editing old entries.
