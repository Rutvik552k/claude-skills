# Idea Card template

Every idea presented to the user must follow this template. Skip nothing — if an axis is genuinely N/A, write "N/A — <one-line reason>" rather than omitting it.

A complete worked example is at the bottom of this file. Read it the first time before producing your own Idea Cards.

## Template

```markdown
### [Idea title — short and specific]

**One-line pitch:** [The contribution in one sentence. Should fit as the first line of a paper abstract.]

**Hypothesis:**
We hypothesize that [specific intervention] applied to [specific setting] will produce [specific measurable outcome with magnitude], because [mechanism / reasoning], supported by [prior result, scaling law, or empirical analogue with citation].

**Why it will work:**
[2-4 sentences of mechanism. What's the chain of causation from intervention to outcome? Reference specific papers or known results. This is where you earn the right to say "this should work" — make the argument.]

**MVP experiment:**
- **Setup:** [Smallest dataset / model / config that could test the hypothesis]
- **Compute:** [Concrete: e.g., "1× A100 40GB for ~6 hours on Lambda Labs (~$8)"]
- **Metric:** [The specific number you'll track]
- **Falsification criterion:** [What result would convince you the hypothesis is wrong]

**6-axis engineering analysis:**

| Axis | Analysis |
|------|----------|
| Time complexity | Training: O(...) — wall-clock ~Xh on [hardware]. Inference: O(...) — Y ms/sample. |
| Space complexity | Model: X GB. Dataset: Y GB on disk. Peak VRAM: Z GB (or "fits in 24GB"). |
| Data structures & algorithms | [Specific named primitives. E.g., "FlashAttention-3 with block-sparse mask, RoPE positional encoding, AdamW with cosine LR schedule, KV cache with rolling window"] |
| API rate limits & cost | [If external API: requests/min budget, $ per run, retry policy. Otherwise: "N/A — fully local execution".] |
| Security & privacy | [Data licensing, model-poisoning surface, prompt-injection if user-facing, PII concerns. "N/A — <reason>" if truly irrelevant.] |
| Cloud infrastructure | [Concrete: hardware + provider + supporting services + monthly $. E.g., "Single g5.12xlarge on AWS spot, S3 for checkpoints, W&B for tracking. ~$300/month at MVP scale."] |

**Risk register:**
1. **[Risk name]** — likelihood: low / med / high. Mitigation: [concrete action]
2. **[Risk name]** — likelihood: ... Mitigation: ...
3. **[Risk name]** — likelihood: ... Mitigation: ...

**Estimated effort:** [solo / small-team / lab-scale] — [rough month-equivalents to publishable result]

**Open-source dependencies:**
- [Repo name] — [URL] — [license note, e.g., "Apache 2.0", "research-only"]
- [Dataset] — [URL] — [license note]
- ...
```

## Quality bar before presenting

Self-check each card against this before showing it to the user:

- [ ] The hypothesis is specific (names the intervention precisely)
- [ ] The hypothesis is falsifiable (a concrete experimental result could disprove it)
- [ ] The hypothesis is grounded (cites a prior result that makes the prediction plausible)
- [ ] The hypothesis has a quantitative target (named metric, expected magnitude)
- [ ] The MVP fits in <1 week of compute and <$500
- [ ] Every axis in the 6-axis table is filled in (with "N/A — <reason>" if not applicable)
- [ ] The risk register has at least 3 entries with concrete mitigations
- [ ] Open-source dependencies are real (verify with web_search if unsure) and links work

If a card fails any check, rewrite it before presenting.

## Worked example

This is the kind of output the skill should produce. Notice how specific everything is — no vague phrases like "use better attention" or "scale it up".

---

### Sparse spatiotemporal attention for video diffusion at 10s+ duration

**One-line pitch:** Replace dense space-time attention in CogVideoX with block-sparse attention restricted to a 3D spatiotemporal locality window plus a small set of global tokens, reducing inference FLOPs ~5× at 10-second 768×1360 generation while retaining ≥95% of VBench overall quality score.

**Hypothesis:**
We hypothesize that replacing dense attention with block-sparse attention (8×8×4 spatiotemporal window + 8 global tokens) in CogVideoX's diffusion transformer will reduce inference FLOPs by ~5× and wall-clock by ~3× at 10-second 768×1360 generation, while degrading VBench overall score by less than 5 points, because (a) trained vision transformers exhibit ~90% attention sparsity in middle layers (NaViT analysis, Beyer et al. 2023), and (b) Lumiere's Space-Time U-Net already implicitly exploits spatial locality, indicating local-only attention is sufficient for video coherence at this resolution.

**Why it will work:**
Diffusion transformers concentrate attention probability mass on spatially-and-temporally-close tokens — Peebles & Xie 2022 ablations confirm this for image DiTs, and video has even stronger locality bias because adjacent frames are near-duplicates. Block-sparse kernels (Triton, FlashAttention-3) make windowed attention efficient on H100 by avoiding the materialized n² attention matrix. The risk that some global cues (camera cuts, narrative shifts) need long-range attention is mitigated by reserving 4-8 "global" tokens that attend densely while all other patches attend only within their local window — this is the Longformer pattern (Beltagy et al. 2020) adapted to 3D video patches.

**MVP experiment:**
- **Setup:** Finetune CogVideoX-2B for 1000 steps on a 5K-clip subset of WebVid-10M with sparse attention swapped into all transformer blocks. Compare against frozen-baseline CogVideoX-2B on a held-out 500-clip eval set.
- **Compute:** 2× H100 80GB for ~24 hours on Lambda Labs (~$120 at $2.50/h/GPU).
- **Metric:** VBench overall score plus inference wall-clock per 10s video. Primary: VBench-Quality. Secondary: VBench-Semantic.
- **Falsification criterion:** Hypothesis is wrong if VBench-Quality degrades by >10 points with no inference speedup, OR no VBench change but no wall-clock speedup either (means sparsity wasn't actually exploited by the kernel).

**6-axis engineering analysis:**

| Axis | Analysis |
|------|----------|
| Time complexity | Inference: O(n · w) instead of O(n²), where n = patches (~8K for 10s @ 768×1360) and w = window size (~256). ~50× fewer attention ops in theory; ~3-5× wall-clock in practice (memory-bandwidth dominated). Training: marginally slower per step due to mask construction overhead; recovery finetuning adds ~$120. |
| Space complexity | Activation memory in attention layers drops from O(n²) to O(n·w): for 8K-patch sequence, 64M floats → 0.5M floats per layer. Model size unchanged (~7 GB for 2B params, fp16). Peak VRAM during inference: ~35 GB (fits on single A100 80GB). |
| Data structures & algorithms | Block-sparse attention via FlashAttention-3 with custom 3D-window mask (or Triton block-sparse kernel as fallback). 3D RoPE for positional encoding across space and time. Mask construction precomputed once per resolution. Longformer-style global tokens (Beltagy et al. 2020) for long-range cues. AdamW + cosine LR schedule for finetuning. |
| API rate limits & cost | N/A — fully local training and inference. |
| Security & privacy | WebVid-10M is research-only license — fine for academic work but restricts commercial deployment. No new attack surface vs base CogVideoX. Standard considerations around generated content (deepfakes, copyright) inherited from the base model and unchanged by this work. |
| Cloud infrastructure | Lambda Labs 2× H100 80GB instance ($5/h all-in) for finetuning runs. S3 (or Lambda's bundled storage) for checkpoints. Weights & Biases for experiment tracking. Total budget to publishable result: ~$1,500 including ablations. Could also run on RunPod H100s ($4-5/h) or Vast.ai (~$3/h, less reliable). |

**Risk register:**
1. **Sparse kernel overhead exceeds savings at this scale** — likelihood: medium. Block-sparse kernels have a fixed overhead that only pays off above a sequence-length threshold. Mitigation: benchmark a no-op sparse mask (sparse data layout but full attention pattern) first to measure the overhead floor before committing to the full experiment.
2. **VBench is insensitive to the quality loss that actually matters** — likelihood: medium. VBench-Quality has known correlations with FVD but human judgments diverge on motion artifacts. Mitigation: budget a small (50-sample) human eval from day one, not as an afterthought; include VBench subscores not just the aggregate.
3. **Global tokens don't capture what they need to** — likelihood: low-medium. The Longformer pattern was developed for 1D text; 3D video may need a different global-token scheme. Mitigation: ablation with 0, 4, 8, 16 global tokens and analyze attention maps to see what they actually attend to.

**Estimated effort:** solo, ~2-3 months to ICLR-quality result (assuming the MVP positive signal lands in week 1).

**Open-source dependencies:**
- CogVideoX — https://github.com/THUDM/CogVideo — Apache 2.0
- FlashAttention-3 — https://github.com/Dao-AILab/flash-attention — BSD-3
- WebVid-10M — https://github.com/m-bain/webvid — research-only license
- VBench — https://github.com/Vchitect/VBench — Apache 2.0
- Weights & Biases — https://wandb.ai — free tier sufficient for solo work
